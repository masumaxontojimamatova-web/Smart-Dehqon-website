# SmartDehqon Website

Bu loyiha SmartDehqon tanlov website prototipi.

## Ishga tushirish
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```
