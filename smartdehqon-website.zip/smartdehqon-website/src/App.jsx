export default function App() {
  const features = [
    { title: "Hosildorlik prognozi", text: "Sun’iy intellekt ob-havo, tuproq va ekin turi bo‘yicha taxminiy hosildorlikni oldindan hisoblaydi." },
    { title: "Kasallikni erta aniqlash", text: "Barg yoki meva rasmi asosida o‘simlikdagi muammoni aniqlab, xavf darajasini ko‘rsatadi." },
    { title: "Offline ishlash", text: "Internet bo‘lmagan hududlarda ham asosiy funksiyalarni ishlatish mumkin." },
    { title: "O‘zbekcha oddiy interfeys", text: "Dehqonlar uchun tushunarli, sodda va tez ishlaydigan platforma dizayni." },
  ];

  const steps = [
    "Dehqon o‘simlik rasmi yoki dala ma’lumotini kiritadi",
    "Tizim AI yordamida tahlil qiladi",
    "Kasallik, xavf va hosildorlik ehtimoli aniqlanadi",
    "Foydalanuvchiga amaliy tavsiya va keyingi qadamlar beriladi",
  ];

  const metrics = [
    { value: "15–25%", label: "hosildorlik oshishi maqsadi" },
    { value: "Offline", label: "internet bo‘lmasa ham ishlash" },
    { value: "O‘zbekcha", label: "mahalliy foydalanuvchi uchun" },
    { value: "AI", label: "aqlli tahlil tizimi" },
  ];

  const audience = ["Dehqonlar", "Fermer xo‘jaliklari", "Agroklasterlar", "Agronomlar", "Talabalar va tadqiqotchilar"];

  return (
    <div style={{fontFamily:"Arial, sans-serif", background:"#06131a", color:"white", minHeight:"100vh"}}>
      <section style={{padding:"64px 24px", borderBottom:"1px solid rgba(255,255,255,0.1)"}}>
        <div style={{maxWidth:1200, margin:"0 auto", display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(320px,1fr))", gap:32, alignItems:"center"}}>
          <div>
            <div style={{display:"inline-block", padding:"10px 16px", borderRadius:999, background:"rgba(16,185,129,0.12)", border:"1px solid rgba(16,185,129,0.25)", color:"#a7f3d0", fontSize:14}}>
              🌾 Mirzo Ulug‘bek vorislari uchun loyiha prototipi
            </div>
            <h1 style={{fontSize:"clamp(36px, 6vw, 64px)", lineHeight:1.08, margin:"18px 0 0", fontWeight:800}}>
              SmartDehqon — sun’iy intellekt asosida hosildorlikni bashoratlash tizimi
            </h1>
            <p style={{marginTop:20, color:"#cbd5e1", fontSize:18, lineHeight:1.8, maxWidth:700}}>
              O‘zbekiston iqlimi va tuproq sharoitiga mos, kasalliklarni erta aniqlaydigan, hosildorlikni prognoz qiladigan va dehqonga amaliy tavsiyalar beradigan aqlli agro-platforma.
            </p>
            <div style={{marginTop:28, display:"flex", gap:12, flexWrap:"wrap"}}>
              <a href="#demo" style={{background:"#10b981", color:"white", textDecoration:"none", padding:"14px 22px", borderRadius:16, fontWeight:700}}>Demo ko‘rish</a>
              <a href="#about" style={{border:"1px solid rgba(255,255,255,0.15)", color:"white", textDecoration:"none", padding:"14px 22px", borderRadius:16, fontWeight:700}}>Loyiha haqida</a>
            </div>
          </div>

          <div style={{display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))", gap:16}}>
            {metrics.map((item) => (
              <div key={item.label} style={{background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.1)", borderRadius:24, padding:24}}>
                <div style={{fontSize:32, fontWeight:800, color:"#6ee7b7"}}>{item.value}</div>
                <div style={{marginTop:8, color:"#cbd5e1", fontSize:14}}>{item.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="about" style={{maxWidth:1200, margin:"0 auto", padding:"56px 24px"}}>
        <div style={{display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(320px,1fr))", gap:24}}>
          <div style={{background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.1)", borderRadius:28, padding:32}}>
            <p style={{letterSpacing:"0.22em", fontSize:12, color:"#86efac", textTransform:"uppercase"}}>Muammo</p>
            <h2 style={{fontSize:34, margin:"10px 0 0", fontWeight:800}}>Nega bu loyiha kerak?</h2>
            <p style={{marginTop:16, color:"#cbd5e1", lineHeight:1.9}}>
              Qishloq xo‘jaligida kasallik va zararkunandalar kech aniqlanishi, iqlim o‘zgarishi, suv tanqisligi va agronomik maslahatlarning yetishmasligi sababli dehqonlar ko‘p hollarda hosilning bir qismini yo‘qotmoqda. SmartDehqon shu muammoni raqamli va amaliy yondashuv bilan hal qiladi.
            </p>
          </div>
          <div style={{background:"rgba(16,185,129,0.12)", border:"1px solid rgba(16,185,129,0.25)", borderRadius:28, padding:32}}>
            <p style={{letterSpacing:"0.22em", fontSize:12, color:"#bbf7d0", textTransform:"uppercase"}}>Maqsad</p>
            <h3 style={{fontSize:30, margin:"10px 0 0", fontWeight:800}}>Kam xarajat, ko‘p hosil</h3>
            <p style={{marginTop:16, color:"#e5e7eb", lineHeight:1.9}}>
              Tizim dehqonga tez qaror qabul qilish, resurslarni tejash va hosildorlikni oshirishga yordam beradi.
            </p>
          </div>
        </div>
      </section>

      <section style={{maxWidth:1200, margin:"0 auto", padding:"0 24px 24px"}}>
        <div style={{display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(240px,1fr))", gap:18}}>
          {features.map((feature) => (
            <div key={feature.title} style={{background:"#0b1720", border:"1px solid rgba(255,255,255,0.1)", borderRadius:24, padding:24}}>
              <h3 style={{fontSize:22, margin:0, fontWeight:700}}>{feature.title}</h3>
              <p style={{marginTop:14, color:"#cbd5e1", lineHeight:1.8, fontSize:15}}>{feature.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="demo" style={{maxWidth:1200, margin:"0 auto", padding:"56px 24px"}}>
        <div style={{display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(320px,1fr))", gap:24}}>
          <div style={{background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.1)", borderRadius:28, padding:32}}>
            <p style={{letterSpacing:"0.22em", fontSize:12, color:"#7dd3fc", textTransform:"uppercase"}}>Qanday ishlaydi</p>
            <h2 style={{fontSize:34, margin:"10px 0 0", fontWeight:800}}>4 bosqichli ishlash jarayoni</h2>
            <div style={{marginTop:24, display:"grid", gap:14}}>
              {steps.map((step, index) => (
                <div key={step} style={{display:"flex", gap:14, alignItems:"flex-start", background:"rgba(2,6,23,0.65)", border:"1px solid rgba(255,255,255,0.08)", padding:16, borderRadius:18}}>
                  <div style={{width:40, height:40, borderRadius:999, display:"grid", placeItems:"center", background:"#10b981", fontWeight:800}}>{index + 1}</div>
                  <p style={{margin:0, color:"#cbd5e1", lineHeight:1.8}}>{step}</p>
                </div>
              ))}
            </div>
          </div>

          <div style={{background:"#0b1720", border:"1px solid rgba(255,255,255,0.1)", borderRadius:28, padding:32}}>
            <p style={{letterSpacing:"0.22em", fontSize:12, color:"#86efac", textTransform:"uppercase"}}>Foydalanuvchilar</p>
            <h2 style={{fontSize:34, margin:"10px 0 0", fontWeight:800}}>Kimlar foydalanadi?</h2>
            <div style={{marginTop:24, display:"flex", gap:10, flexWrap:"wrap"}}>
              {audience.map((item) => (
                <span key={item} style={{padding:"10px 14px", borderRadius:999, border:"1px solid rgba(255,255,255,0.1)", background:"rgba(255,255,255,0.05)", color:"#e2e8f0", fontSize:14}}>{item}</span>
              ))}
            </div>
            <div style={{marginTop:24, background:"rgba(253,224,71,0.08)", border:"1px solid rgba(253,224,71,0.18)", borderRadius:18, padding:18, color:"#fef3c7", lineHeight:1.8, fontSize:14}}>
              Keyingi bosqichda bu platformaga ob-havo API, tuproq tahlili, ekin turi bo‘yicha tavsiyalar va dashboard qo‘shilishi mumkin.
            </div>
          </div>
        </div>
      </section>

      <section style={{maxWidth:1200, margin:"0 auto", padding:"0 24px 24px"}}>
        <div style={{border:"1px solid rgba(255,255,255,0.1)", borderRadius:32, background:"linear-gradient(90deg, rgba(16,185,129,0.15), rgba(34,211,238,0.10))", padding:32}}>
          <h2 style={{fontSize:34, margin:0, fontWeight:800}}>Loyihaning ustun tomonlari</h2>
          <div style={{marginTop:22, display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(240px,1fr))", gap:14}}>
            {[
              "Mahalliy sharoitga moslashtirilgan model",
              "O‘zbek tilida sodda interfeys",
              "Telefon orqali foydalanish imkoniyati",
              "Kelajakda mobil ilova va analitika bilan kengaytirish mumkin",
            ].map((item) => (
              <div key={item} style={{background:"rgba(2,6,23,0.55)", borderRadius:18, padding:18, color:"#e2e8f0"}}>{item}</div>
            ))}
          </div>
        </div>
      </section>

      <section style={{maxWidth:1200, margin:"0 auto", padding:"0 24px 24px"}}>
        <div style={{display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(320px,1fr))", gap:24}}>
          <div style={{background:"rgba(255,255,255,0.05)", border:"1px solid rgba(255,255,255,0.1)", borderRadius:28, padding:32}}>
            <p style={{letterSpacing:"0.22em", fontSize:12, color:"#86efac", textTransform:"uppercase"}}>Pilot natijalar</p>
            <h2 style={{fontSize:34, margin:"10px 0 0", fontWeight:800}}>Loyihadan kutilayotgan foyda</h2>
            <ul style={{marginTop:20, color:"#cbd5e1", lineHeight:1.9, paddingLeft:20}}>
              <li>Kasalliklarni erta aniqlash orqali hosil yo‘qotishlarini kamaytirish</li>
              <li>Suv, vaqt va agronomik resurslardan samaraliroq foydalanish</li>
              <li>Fermer va dehqonlar uchun tezkor raqamli tavsiyalar</li>
              <li>Hududiy agro-analitika yaratish uchun asos bo‘lish</li>
            </ul>
          </div>
          <div style={{background:"#0b1720", border:"1px solid rgba(255,255,255,0.1)", borderRadius:28, padding:32}}>
            <p style={{letterSpacing:"0.22em", fontSize:12, color:"#7dd3fc", textTransform:"uppercase"}}>Kelajak rejasi</p>
            <h2 style={{fontSize:34, margin:"10px 0 0", fontWeight:800}}>Roadmap</h2>
            <div style={{marginTop:22, display:"grid", gap:12}}>
              {[
                "1-bosqich: Dataset va pilot hudud tanlash",
                "2-bosqich: AI model va web prototip tayyorlash",
                "3-bosqich: Fermerlar bilan sinovdan o‘tkazish",
                "4-bosqich: Mobil ilova va kengaytirilgan analitika",
              ].map((item) => (
                <div key={item} style={{border:"1px solid rgba(255,255,255,0.1)", borderRadius:18, padding:16, color:"#cbd5e1"}}>{item}</div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section style={{maxWidth:1200, margin:"0 auto", padding:"0 24px 64px"}}>
        <div style={{border:"1px solid rgba(16,185,129,0.25)", borderRadius:32, background:"rgba(16,185,129,0.12)", padding:"40px 24px", textAlign:"center"}}>
          <p style={{letterSpacing:"0.22em", fontSize:12, color:"#bbf7d0", textTransform:"uppercase"}}>Bog‘lanish</p>
          <h2 style={{fontSize:34, margin:"10px 0 0", fontWeight:800}}>SmartDehqon bilan raqamli qishloq xo‘jaligi sari</h2>
          <p style={{maxWidth:760, margin:"16px auto 0", color:"#e5e7eb", lineHeight:1.9}}>
            Ushbu platforma dehqonlarga sun’iy intellekt yordamida tezroq, aniqroq va samaraliroq qaror qabul qilish imkonini beradi.
          </p>
          <div style={{marginTop:26, display:"flex", justifyContent:"center", gap:12, flexWrap:"wrap"}}>
            <a href="mailto:smartdehqon@example.com" style={{background:"white", color:"#0f172a", textDecoration:"none", padding:"14px 22px", borderRadius:16, fontWeight:700}}>Email</a>
            <a href="tel:+998900000000" style={{border:"1px solid rgba(255,255,255,0.2)", color:"white", textDecoration:"none", padding:"14px 22px", borderRadius:16, fontWeight:700}}>Telefon</a>
          </div>
        </div>
      </section>
    </div>
  );
}
